Sum=1
gangetall=1
while Sum<1000:
    Sum=Sum*gangetall
    gangetall+=1
print(Sum)