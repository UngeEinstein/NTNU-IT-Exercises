sum=0
antall_runder=0
while antall_runder<7:
    antall_runder+=1
    Heltall=int(input("Skriv inn et heltall "))
    sum+=Heltall
print("Summen av alle heltallene er {0}".format(sum))