for hour in range(0,25):
    for min in range(0,60):
        print("{:02d}:{:02d}".format(hour,min),end="\n")
  