for x in range(1,11):
    print()
    for y in range(1,11):
        print(x*y,end=" ")
  