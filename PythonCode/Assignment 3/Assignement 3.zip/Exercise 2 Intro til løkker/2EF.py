for tall in range(1,6):
    print(tall, end=" ")
print()   

for tall in range(15,0,-1):
    print(tall, end=" ")  