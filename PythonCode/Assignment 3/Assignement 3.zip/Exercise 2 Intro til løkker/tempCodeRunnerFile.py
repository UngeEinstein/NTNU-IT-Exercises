for tall in range(15,0,-11):
    print(tall, end=" ")    