print("Oddetallene fra 1 til 20:")
for number in range(1, 20, 2):
    print(number, end = " ")
print()
  
print("Tallene i 3-gangen mellom 12 og 25:")
for number in range(12, 25, 3):
    print(number, end = " ")
print()
  
print("Tallene i 5-gangen mellom 20 og 81:")
for number in range(20, 81, 5): ###
    print(number, end = " ")
print()
  
print("Tallsekvensen 48, 56, 64, 72, 80")
for number in range(48,81,8): ###
    print(number, end = " ")
print()
  
print("Telle baklengs fra 100 til 80, med intervall på -3, dvs. 100, 97, ...:")
for number in range(100,80,-3): ###
    print(number, end = " ")
print()